const path = require("path");
// Temporary JSON DB to store tasks.
// MongoDB is not available right now in newer version of Debian Linux.
// Thats why I opted to use JSONDB.
const { JsonDB, Config } = require("node-json-db");
const db = new JsonDB(new Config("taskDB", true, false, "/"));
// Initializing the express application.
// Setting the port to 8000 to avoid conflicts with React's default port.
const express = require("express");
const app = express();
const port = 8000;

// Only for this app, to run both nodeJS script and ReactJS in the same machine.
// To avoid CORS same origin error.
const cors = require("cors");
app.use(cors());

// CatchAsyn is used to wrap over any asynchronous middleware,
// To allow for easier error handling capabilites.
// By default Express Error handling is not supported in async operations
const CatchAsync = require("./utilities/CatchAsync");

// ExpressError is a custom Error class extending features of Error Class and adding in
// few properties like status and message.
const ExpressError = require("./utilities/ExpressError");

app.use(express.static(path.join(__dirname, "build")));

// JSON content type and urlencoded content type Body Parsers.
// It helps in getting data in req.body property.
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "/build/index.html"));
});
app.get("/tasks", (req, res) => {
  res.sendFile(path.join(__dirname, "/build/index.html"));
});

// GET route to get all the tasks from JSONDB.
app.get(
  "/api/v1/tasks",
  CatchAsync(async (req, res) => {
    const data = await db.getData("/tasks");
    res.send({ status: 200, success: "Retrived Data successfully", data });
  })
);

// POST route to add in a new task into JSONDB.
app.post(
  "/api/v1/tasks/create",
  CatchAsync(async (req, res) => {
    const newData = req.body;

    // Check for availability of required data.
    if (!(newData.name || newData.id)) {
      throw new ExpressError("Incorrect Data", 402);
    }
    await db.push(`/tasks/${newData.id}`, { ...newData });
    res.send({
      status: 200,
      success: "Successfully added data",
      data: newData,
    });
  })
);
app.put(
  "/api/v1/tasks/:id",
  CatchAsync(async (req, res) => {
    const { id } = req.params;
    const updateData = req.body;

    // Check for availability of required data.
    await db.push(`/tasks/${id}`, { id, ...updateData });
    res.send({
      status: 200,
      success: "Successfully added data",
      data: updateData,
    });
  })
);

// POST route to get single task.
app.get(
  "/api/v1/tasks/:id",
  CatchAsync(async (req, res) => {
    const { id } = req.params;

    // Check for availability of required data.
    if (!id) {
      throw new ExpressError("Incorrect ID", 402);
    }
    const data = await db.getData(`/tasks/${id}`);
    res.send({ status: 200, success: "Retrived Data successfully", data });
  })
);

// DELETE route to delete specific task or all the tasks at once based on delId parameter.
app.delete(
  "/api/v1/tasks/:id",
  CatchAsync(async (req, res) => {
    const delId = req.params.id;

    // Check for deletion id
    if (!delId) {
      throw new ExpressError(
        "Insufficient Data provided to delete an item",
        402
      );
    }

    // If delId is all then we clear the DB and setup a fresh one.
    // If delId is any other id we then clear the task from the DB.
    if (delId === "all") {
      await db.delete(`/tasks/`);
      await db.push("/tasks/", []);
    } else {
      await db.delete(`/tasks/${delId}`);
    }
    res.send({
      status: 200,
      success: "Successfully deleted data",
      delId: delId,
    });
  })
);

// All other routes handler to allow smoother error handling
app.use("*", (req, res) => {
  throw new ExpressError("Page Not Found", 404);
});

// Error Handling middleware - whenever we encounter any throw statement,
// The middleware here is run to provide user with acurate response.
app.use((err, req, res, next) => {
  const { status = 500, message = "Something went wrong" } = err;

  // Setting the status and returning error message.
  res.status(status).send({ status, error: message });
});

// Setting up the application to listen for requests in the desired port.
app.listen(port, () => {
  console.log("Server running");
});
