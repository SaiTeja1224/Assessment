<!-- FRONTEND SETUP -->

# Using Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm install`

Runs the package installer.\

It takes a bit of time, once its done move to the next step.\

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm run build`

Builds the app in the optimized mode.\
The page will reload when you make changes.\

once its done move to the below commands to view it in browser.

### `npm install -g serve`

### `serve -s build`

<!-- BACKEND SETUP -->

## Inital

Please make sure you have NodeJS available in your PC.

You can download it from [https://nodejs.org/en] (LTS Version is recommended)

## Available Scripts

In the project directory, you can run:

### `npm install`

Runs the package installer.\

It takes a bit of time, once its done move to the next step.\

### `npm start`

To start up the server and allows to access different actions for tasks
