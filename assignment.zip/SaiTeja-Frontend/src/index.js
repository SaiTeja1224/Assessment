import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import { Provider } from "react-redux";
import store from "./Redux/store";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import AddTasks from "./Components/AddTasks/AddUpdateTasks";
import TaskItem from "./Components/Task/TaskItem";
import Loading from "./Components/UI/Loader/Loading";

const root = ReactDOM.createRoot(document.getElementById("root"));

// CONFIGURING ROUTES
const router = createBrowserRouter([
  {
    path: "/",
    element: <Loading />,
  },
  {
    path: "/tasks",
    element: <App />,
  },
  {
    path: "/tasks/create",
    element: <AddTasks />,
  },
  {
    path: "/tasks/:id",
    element: <TaskItem />,
  },
]);

// PROVIDING STORE AND ROUTES TO ALL COMPONENTS UNDER app.js
root.render(
  <Provider store={store}>
    <React.StrictMode>
      <article className="task-app">
        <RouterProvider router={router} />
      </article>
    </React.StrictMode>
  </Provider>
);
