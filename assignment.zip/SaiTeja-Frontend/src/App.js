import Header from "./Components/Header/Header";
import Tasks from "./Components/Task/Tasks";
import Result from "./Components/Result/Result";
import Button from "./Components/UI/Button/Button";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { deleteTask, fetchTasks } from "./Redux/actions/tasks";
import { useNavigate } from "react-router-dom";
function App() {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { error, tasks } = useSelector((state) => state.task);

  // This is to perform initital request to get all the data from backend and display it using
  // Redux State
  useEffect(() => {
    dispatch(fetchTasks());
  }, [dispatch]);

  // Request to delete all or single piece of data/tasks
  const delDataRequest = (delId) => {
    dispatch(deleteTask(delId));
  };

  // if there is any error from getting data or deleting we display error message or else
  // we display normal content
  const appContent = error?.length ? (
    <p>{error}</p>
  ) : (
    <>
      <section className="add-container">
        <Header>Task List</Header>
        <Button
          handler={() => {
            navigate("/tasks/create");
          }}
        >
          Add Task
        </Button>
      </section>
      <section>
        <Tasks tasks={tasks} />
        <Result count={tasks.length} allCompleteHelper={delDataRequest} />
      </section>
    </>
  );

  return <>{appContent}</>;
}

export default App;
