import React from "react";

// Simple Heading
export default function Header(props) {
  return (
    <>
      <h1>{props.children}</h1>
    </>
  );
}
