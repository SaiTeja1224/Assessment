import React, { useEffect, useRef, useState } from "react";
import Button from "../UI/Button/Button";
import Input from "../UI/Input/Input";
import { useDispatch, useSelector } from "react-redux";
import { addTask, fetchTask, updateTask } from "../../Redux/actions/tasks";
import Header from "../Header/Header";
import { useNavigate, useParams } from "react-router-dom";

export default function AddTasks(props) {
  const { tasks, task } = useSelector((state) => state.task);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // Fetching id from params to edit existing task.
  const { id } = useParams();

  // props.update is a boolean when set true it means we use this component to edit the data.
  // props.update is set true/false in
  useEffect(() => {
    if (props.update) {
      dispatch(fetchTask(id));
    }
  }, [dispatch, props.update]);

  useEffect(() => {
    if (props.update) {
      enteredTask.current.value = task.name;
      enteredDescription.current.value = task.description;
      enteredDueDate.current.value = task.dueDate;
      setTaskError(false);
      setDescriptionError(false);
      setDueDateError(false);
    }
  }, [task, props.update]);

  // UseRef to access DOM element directly.
  const enteredTask = useRef(null);
  const enteredDescription = useRef(null);
  const enteredDueDate = useRef(null);

  // Error States for each inputs available
  const [taskError, setTaskError] = useState(true);
  const [descriptionError, setDescriptionError] = useState(true);
  const [dueDateError, setDueDateError] = useState(true);

  const addDataRequest = (newData) => {
    if (props.update) {
      // Logic for updaing data
      const updatedTask = { ...newData };
      dispatch(updateTask({ id, updatedTask }));
      props.handleUpdate();
    } else {
      // Logic for adding new data
      const newId = tasks.length;
      const newTask = { id: newId, ...newData, marked: false };
      dispatch(addTask(newTask));
      navigate("/tasks");
    }
  };

  // To get the value from DOM using ref and reseting the form.
  const addTaskHandler = function (e) {
    e.preventDefault();
    const taskName = enteredTask.current.value;
    const taskDescription = enteredDescription.current.value;
    const taskDueDate = enteredDueDate.current.value;
    addDataRequest({
      name: taskName,
      description: taskDescription,
      dueDate: taskDueDate,
    });
    enteredTask.current.value = "";
    enteredDescription.current.value = "";
    enteredDueDate.current.value = "";
    setDescriptionError(true);
    setTaskError(true);
    setDueDateError(true);
  };

  // Getting error from Task Input field.
  const getTaskError = (error) => {
    setTaskError(error);
  };

  // Getting error from Description Input field.
  const getDescriptionError = (error) => {
    setDescriptionError(error);
  };

  // Getting error from DueDate Input field.
  const getDueDateError = (error) => {
    setDueDateError(error);
  };

  return (
    <section>
      <section className="back-container">
        <Header>{props.update ? "Update Task" : "Create Task"}</Header>
        <Button
          handler={() => {
            props.update ? props.handleUpdate() : navigate("/");
          }}
        >
          Go Back
        </Button>
      </section>
      <form onSubmit={addTaskHandler}>
        {/* Input Reusable Component for Task Name*/}
        <label>
          Task Name
          <Input
            type="text"
            name="name"
            inputRef={enteredTask}
            cName="text-box mb-3 mt-3"
            sendError={getTaskError}
          />
        </label>
        {/* Input Reusable Component for Description */}
        <label>
          Description
          <Input
            type="textarea"
            name="description"
            inputRef={enteredDescription}
            cName="text-box mb-3 mt-3"
            sendError={getDescriptionError}
          />
        </label>
        {/* Input Reusable Component for Due Date */}
        <label>
          Due Date
          <Input
            type="date"
            name="dueDate"
            inputRef={enteredDueDate}
            cName="text-box mb-3 mt-3"
            sendError={getDueDateError}
          />
        </label>
        {/* Button Reusable Component */}
        <div className="text-align-center">
          <Button
            type="submit"
            cName="add"
            disable={taskError || descriptionError || dueDateError}
          >
            {props.update ? "Update" : "Create"}
          </Button>
        </div>
      </form>
    </section>
  );
}
