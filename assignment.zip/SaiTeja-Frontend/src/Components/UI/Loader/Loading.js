import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Loading = () => {
  // ON Initial Load move to tasks page.
  const navigate = useNavigate();
  useEffect(() => {
    navigate("/tasks", { replace: true });
  });
  return <div>...Loading</div>;
};

export default Loading;
