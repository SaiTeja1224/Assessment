import React from "react";
import { useSelector } from "react-redux";
import Button from "../UI/Button/Button";
import classes from "./Tasks.module.css";
import { useNavigate } from "react-router-dom";

export default function Todos() {
  const { tasks, error } = useSelector((state) => state.task);
  const navigate = useNavigate();

  // Extracting individual items from the array and creating components.
  const todoItems = tasks.map((items, i) => (
    <>
      <section
        className={
          !items?.marked
            ? `${classes["task"]}`
            : `${classes["task"]} ${classes["marked"]}`
        }
      >
        <p>
          {items.name} {!items?.marked ? "" : "(Complete)"}
        </p>
        {/* Button Reusable Component */}
        <Button
          type="button"
          cName="view"
          handler={() => {
            navigate(`/tasks/${items.id}`);
          }}
        >
          View
        </Button>
      </section>
    </>
  ));

  // if there is any error from getting data we display error message or else
  // we display normal content
  const content = error?.length ? <p>{error}</p> : todoItems;
  return content;
}
