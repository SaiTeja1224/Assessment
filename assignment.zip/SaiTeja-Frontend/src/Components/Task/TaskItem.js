import React, { useEffect, useState } from "react";
import Button from "../UI/Button/Button";

import classes from "./TaskItem.module.css";
import { useDispatch, useSelector } from "react-redux";
import { deleteTask, fetchTask, updateTask } from "../../Redux/actions/tasks";
import { useNavigate, useParams } from "react-router-dom";
import Header from "../Header/Header";
import AddTasks from "../AddTasks/AddUpdateTasks";

export default function TodoItem() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { task, error } = useSelector((state) => state.task);
  const { id } = useParams();

  // TO TOGGLE BETWEEN EDIT/UPDATE records and ADDING/CREATING new records.
  const [edit, setEdit] = useState("");

  // MARKED STATE
  const [marked, setMarked] = useState(false);

  useEffect(() => {
    dispatch(fetchTask(id));
  }, [dispatch, id]);

  useEffect(() => {
    setMarked(task?.marked);
  }, [task?.marked]);

  // This is a function to handle the deletion of task.
  const deleteHandler = function () {
    dispatch(deleteTask(id));
    navigate("/tasks");
  };

  // SETTING EDIT STATE IS DONE IN THIS FUNCTION
  const handleUpdate = () => {
    setEdit("");
  };

  const handleMarked = () => {
    setMarked(true);
    dispatch(updateTask({ id, updatedTask: { ...task, marked: true } }));
  };

  // if there is any error from getting data or deleting we display error message or else
  // we display normal content
  const content = error?.length ? (
    <p>{error}</p>
  ) : !edit ? (
    <>
      <section className="back-container">
        <Header>Single Task</Header>
        <Button
          handler={() => {
            navigate("/tasks");
          }}
        >
          Go Back
        </Button>
      </section>
      <section
        // CHANGING STYLES BASED ON MARKING
        className={
          !marked
            ? `${classes["task-item"]}`
            : `${classes["task-item"]} ${classes["marked"]}`
        }
      >
        <p>
          Name : <span>{task.name}</span>
        </p>
        <p>
          Description : <span>{task.description}</span>
        </p>
        <p>
          Due Date :{" "}
          <span>
            {task.dueDate
              ? new Date(task.dueDate).toLocaleDateString("en-IN")
              : "No date specified!"}
          </span>
        </p>
        {/* Button Reusable Component */}
        <div className="text-align-end">
          <Button
            type="button"
            cName="view me-3"
            handler={() => {
              setEdit(id);
            }}
          >
            Update
          </Button>
          <Button type="button" cName="delete" handler={deleteHandler}>
            Delete
          </Button>
        </div>

        {/* MARKING TASK COMPLETION LOGIC */}
        {marked ? (
          <span className={classes["marked-indicator"]}>Complete</span>
        ) : (
          <label className={classes["marked-indicator"]}>
            <input
              type="checkbox"
              id="marking"
              name={id}
              className="me-3"
              checked={marked}
              disabled={marked}
              onChange={handleMarked}
            />
            Is Complete?
          </label>
        )}
      </section>
    </>
  ) : (
    <>
      <AddTasks update={true} handleUpdate={handleUpdate} />
    </>
  );

  return content;
}
