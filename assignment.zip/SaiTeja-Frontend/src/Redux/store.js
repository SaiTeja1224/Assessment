import { configureStore } from "@reduxjs/toolkit";
import tasks from "./reducers/tasksSlice";

// MAIN REDUX STORE
const store = configureStore({
  reducer: {
    task: tasks,
  },
});

export default store;
