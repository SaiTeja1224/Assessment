import { createSlice } from "@reduxjs/toolkit";
// ALL THE ACTION THUNKS
import {
  addTask,
  deleteTask,
  fetchTask,
  fetchTasks,
  updateTask,
} from "../actions/tasks";

// INITIAL APPLICATION STATE FOR TASKS
const inititalState = {
  loading: false,
  tasks: [],
  task: {},
  error: "",
};

// CREATION OF TASK SLICE TO USE IN STORE
const taskSlice = createSlice({
  name: "task",
  initialState: inititalState,
  reducers: {},
  extraReducers: (builder) => {
    builder

      // FETCHING ALL TASKS REDUCERS
      .addCase(fetchTasks.pending, (state) => {
        state.loading = true;
        state.error = "";
      })
      .addCase(fetchTasks.fulfilled, (state, action) => {
        state.loading = false;
        const newData = action.payload.filter((item) => !!item);
        state.tasks = newData;
      })
      .addCase(fetchTasks.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      // FETCHING SINGLE TASK REDUCERS
      .addCase(fetchTask.pending, (state) => {
        state.loading = true;
        state.error = "";
      })
      .addCase(fetchTask.fulfilled, (state, action) => {
        state.loading = false;
        state.task = action.payload;
      })
      .addCase(fetchTask.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      // ADD SINGLE TASK REDUCERS
      .addCase(addTask.pending, (state) => {
        state.loading = true;
        state.error = "";
      })
      .addCase(addTask.fulfilled, (state, action) => {
        state.loading = false;
        console.log(action.payload);
        state.tasks = [...state.tasks, action.payload];
      })
      .addCase(addTask.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      // UPDATE SINGLE TASK REDUCERS
      .addCase(updateTask.pending, (state) => {
        state.loading = true;
        state.error = "";
      })
      .addCase(updateTask.fulfilled, (state, action) => {
        state.loading = false;
        const updatedTasks = state.tasks.map((item) => {
          if (item.id === action.payload.id) {
            const updatedItem = { ...action.payload };
            return updatedItem;
          } else {
            return item;
          }
        });
        state.task = action.payload;
        state.tasks = updatedTasks;
      })
      .addCase(updateTask.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })

      // DELETE TASKS REDUCERS
      .addCase(deleteTask.pending, (state) => {
        state.loading = true;
        state.error = "";
      })
      .addCase(deleteTask.fulfilled, (state, action) => {
        state.loading = false;
        if (action.payload === "all") {
          state.tasks = [];
        } else {
          state.tasks = state.tasks.filter((item) => {
            return item.id !== +action.payload;
          });
        }
      })
      .addCase(deleteTask.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

export default taskSlice.reducer;
