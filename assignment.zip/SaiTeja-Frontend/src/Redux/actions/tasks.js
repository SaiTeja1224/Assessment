import { createAsyncThunk } from "@reduxjs/toolkit";

// ACTION THUNKS/ACTION CREATORS

// FETCHING
export const fetchTasks = createAsyncThunk("task/fetch", async () => {
  try {
    const response = await fetch("http://localhost:8000/api/v1/tasks", {
      method: "GET",
    });
    const jsonResponse = await response.json();
    if (jsonResponse.status !== 200) {
      throw new Error("Failed to fetch tasks!");
    }
    return jsonResponse.data;
  } catch (error) {
    throw error;
  }
});

// FETCHING SINGLE RECORD
export const fetchTask = createAsyncThunk("task/single", async (id) => {
  try {
    const response = await fetch(`http://localhost:8000/api/v1/tasks/${id}`, {
      method: "GET",
    });
    const jsonResponse = await response.json();
    if (jsonResponse.status !== 200) {
      throw new Error("Failed to fetch task!");
    }
    return jsonResponse.data;
  } catch (error) {
    throw error;
  }
});

// ADDING SINGLE RECORD
export const addTask = createAsyncThunk("task/add", async (newTask) => {
  try {
    const response = await fetch(`http://localhost:8000/api/v1/tasks/create`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(newTask),
    });
    const jsonResponse = await response.json();
    if (jsonResponse.status !== 200) {
      throw new Error("Failed to add task!");
    }
    return jsonResponse.data;
  } catch (error) {
    throw error;
  }
});

// UPDATING SINGLE RECORD
export const updateTask = createAsyncThunk(
  "task/update",
  async ({ id, updatedTask }) => {
    try {
      const response = await fetch(`http://localhost:8000/api/v1/tasks/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updatedTask),
      });
      const jsonResponse = await response.json();
      if (jsonResponse.status !== 200) {
        throw new Error("Failed to add task!");
      }
      return jsonResponse.data;
    } catch (error) {
      throw error;
    }
  }
);

// DELETING SINGLE/MULTIPLE RECORD
export const deleteTask = createAsyncThunk("task/delete", async (delId) => {
  try {
    let url = `http://localhost:8000/api/v1/tasks/${delId}`;

    // if we send "all" in the delId we delete all the tasks. Else we delete specified task.
    if (delId === "all") {
      url = `http://localhost:8000/api/v1/tasks/all`;
    }
    const response = await fetch(url, {
      method: "DELETE",
    });
    const jsonResponse = await response.json();
    if (jsonResponse.status !== 200) {
      throw new Error("Failed to delete task!");
    }
    return jsonResponse.delId;
  } catch (error) {
    throw error;
  }
});
