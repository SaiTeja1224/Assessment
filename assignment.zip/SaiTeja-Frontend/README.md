<!-- FRONTEND SETUP -->

# Using Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm install`

Runs the package installer.\

It takes a bit of time, once its done move to the next step.\

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:8000](http://localhost:8000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

<!-- BACKEND SETUP -->

## Inital

Please make sure you have NodeJS available in your PC.

You can download it from [https://nodejs.org/en] (LTS Version is recommended)

## Available Scripts

In the project directory, you can run:

### `npm install`

Runs the package installer.\

It takes a bit of time, once its done move to the next step.\

### `npm start`

To start up the server and allows to access different actions for tasks
